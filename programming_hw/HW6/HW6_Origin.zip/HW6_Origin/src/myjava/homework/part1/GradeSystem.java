package myjava.homework.part1;
import static java.lang.System.out;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
public class GradeSystem {
    static ArrayList<StudentGrade> studentGrades;
    public static void main(String[] args) {
        studentGrades = new ArrayList<StudentGrade>();
    }
}
