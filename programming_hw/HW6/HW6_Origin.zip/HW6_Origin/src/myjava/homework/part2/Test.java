package myjava.homework.part2;

public class Test {
    int x;
    String y;
    boolean z;
    public Test(){
        x = 1;
        y = "12345";
        z = true;
    }
}
