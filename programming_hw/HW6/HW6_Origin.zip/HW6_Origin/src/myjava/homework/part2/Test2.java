package myjava.homework.part2;

public class Test2 {
    int x;
    boolean y;
    boolean z;
    int a;
    String b;
    String c;
    public Test2(){
        x = 1;
        y = true;
        z = false;
        a = 17;
        b = "English";
        c = "Chinese";
    }
}
